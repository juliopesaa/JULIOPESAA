streamlit_app.py - Main file
settings.py - Config. file
EDA/eda.py - EDA Analysis
